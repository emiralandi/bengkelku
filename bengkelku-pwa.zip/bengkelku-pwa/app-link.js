// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://bengkelku-bmwrqm.zedeai2026.workers.dev";
