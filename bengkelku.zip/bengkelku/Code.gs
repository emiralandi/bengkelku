var SPREADSHEET_ID_PROP = 'SPREADSHEET_ID';
var ADMIN_EMAIL_PROP = 'ADMIN_EMAIL';
var ADMIN_PASSWORD_PROP = 'ADMIN_PASSWORD';
var APP_SECRET_PROP = 'APP_SECRET';
var SAMPLE_IDS_PROP = 'SAMPLE_IDS';

function doGet(e) {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('BengkelPro — Manajemen Bengkel & Work Order')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .addMetaTag('mobile-web-app-capable', 'yes')
    .addMetaTag('apple-mobile-web-app-capable', 'yes')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function csAppUrl() {
  return ScriptApp.getService().getUrl();
}

function getSpreadsheet_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty(SPREADSHEET_ID_PROP);
  var ss = null;
  if (id) {
    try {
      ss = SpreadsheetApp.openById(id);
    } catch (err) {
      ss = null;
    }
  }
  if (!ss) {
    try {
      ss = SpreadsheetApp.getActiveSpreadsheet();
    } catch (err2) {
      ss = null;
    }
  }
  if (!ss) {
    ss = SpreadsheetApp.create('BengkelPro Database');
    props.setProperty(SPREADSHEET_ID_PROP, ss.getId());
  }
  return ss;
}

function setupDatabase() {
  var ss = getSpreadsheet_();
  var props = PropertiesService.getScriptProperties();

  if (!props.getProperty(APP_SECRET_PROP)) {
    props.setProperty(APP_SECRET_PROP, Utilities.getUuid());
  }
  if (!(props.getProperty(ADMIN_EMAIL_PROP) || 'admin@app.local')) {
    props.setProperty(ADMIN_EMAIL_PROP, 'admin@bengkelpro.id');
  }
  if (!(props.getProperty(ADMIN_PASSWORD_PROP) || 'fjbb33vqw4')) {
    props.setProperty(ADMIN_PASSWORD_PROP, 'Password123');
  }

  var sheetsConfig = [
    {
      name: 'Pelanggan',
      columns: ['id', 'nama', 'no_hp', 'alamat', 'createdAt'],
      formats: { 3: '@' }
    },
    {
      name: 'Kendaraan',
      columns: ['id', 'pelanggan', 'nomor_polisi', 'merek', 'model', 'tahun', 'createdAt'],
      formats: { 3: '@' }
    },
    {
      name: 'Layanan & Harga',
      columns: ['id', 'nama_layanan', 'kategori', 'harga', 'createdAt'],
      formats: {}
    },
    {
      name: 'Suku Cadang',
      columns: ['id', 'nama_part', 'stok', 'harga_beli', 'harga_jual', 'createdAt'],
      formats: {}
    },
    {
      name: 'Mekanik',
      columns: ['id', 'nama', 'spesialisasi', 'no_hp', 'createdAt'],
      formats: { 4: '@' }
    },
    {
      name: 'Pesanan',
      columns: ['id', 'no_pesanan', 'tanggal', 'pelanggan', 'kendaraan', 'mekanik', 'item', 'total', 'dp', 'status', 'tanggal_kirim', 'createdAt'],
      formats: { 2: '@', 11: '@' }
    },
    {
      name: 'Tagihan',
      columns: ['id', 'no_tagihan', 'pesanan', 'total', 'diskon', 'pajak', 'sisa_bayar', 'status_bayar', 'createdAt'],
      formats: { 2: '@' }
    },
    {
      name: 'Users',
      columns: ['id', 'username', 'nama', 'role', 'passwordHash', 'salt', 'passwordAwal', 'aktif', 'createdAt'],
      formats: { 1: '@' }
    },
    {
      name: 'Activity',
      columns: ['id', 'user', 'action', 'details', 'createdAt'],
      formats: {}
    },
    {
      name: 'Pengaturan',
      columns: ['key', 'value'],
      formats: {}
    }
  ];

  var sampleIds = {};

  sheetsConfig.forEach(function(cfg) {
    var sheet = ss.getSheetByName(cfg.name);
    if (!sheet) {
      sheet = ss.insertSheet(cfg.name);
      sheet.appendRow(csSheetText_(cfg.columns));
      sheet.setFrozenRows(1);
    } else if (sheet.getLastRow() === 0) {
      sheet.appendRow(csSheetText_(cfg.columns));
      sheet.setFrozenRows(1);
    }

    if (cfg.formats) {
      for (var colIdx in cfg.formats) {
        var range = sheet.getRange(2, Number(colIdx), Math.max(1, sheet.getMaxRows() - 1), 1);
        range.setNumberFormat(cfg.formats[colIdx]);
      }
    }

    // Insert samples if sheet is empty (only header exists)
    if (sheet.getLastRow() === 1) {
      var samples = getSamplesForSheet_(cfg.name);
      if (samples && samples.length > 0) {
        var ids = [];
        samples.forEach(function(row) {
          sheet.appendRow(csSheetText_(row));
          ids.push(row[0]);
        });
        sampleIds[cfg.name] = ids;
      }
    }
  });

  // Ensure default users
  var userSheet = ss.getSheetByName('Users');
  if (userSheet.getLastRow() === 1) {
    var salt = Utilities.getUuid();
    var hash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + 'Password123');
    var hashHex = bytesToHex_(hash);
    userSheet.appendRow(csSheetText_(['USR-001', 'admin@bengkelpro.id', 'Hendra Wijaya', 'Admin / Pemilik', hashHex, salt, 'Password123', true, new Date().toISOString()]));
    userSheet.appendRow(csSheetText_(['USR-002', 'staf@bengkelpro.id', 'Rina Agustina', 'Staf', hashHex, salt, 'Password123', true, new Date().toISOString()]));
    userSheet.appendRow(csSheetText_(['USR-003', 'mekanik@bengkelpro.id', 'Andi Pratama', 'Mekanik', hashHex, salt, 'Password123', true, new Date().toISOString()]));
  }

  // Ensure default settings
  var settSheet = ss.getSheetByName('Pengaturan');
  if (settSheet.getLastRow() === 1) {
    settSheet.appendRow(csSheetText_(['nama_bengkel', 'BengkelPro Cabang Utama']));
    settSheet.appendRow(csSheetText_(['alamat_bengkel', 'Jl. Otista Raya No. 45, Jakarta Selatan']));
    settSheet.appendRow(csSheetText_(['telepon_bengkel', '081234567890']));
    settSheet.appendRow(csSheetText_(['pajak_persen', '11']));
  }

  props.setProperty(SAMPLE_IDS_PROP, JSON.stringify(sampleIds));
  return { ok: true, message: 'Database siap digunakan' };
}

function bytesToHex_(bytes) {
  var output = [];
  for (var i = 0; i < bytes.length; i++) {
    var val = bytes[i];
    if (val < 0) val += 256;
    var hex = val.toString(16);
    if (hex.length === 1) hex = '0' + hex;
    output.push(hex);
  }
  return output.join('');
}

function getSamplesForSheet_(name) {
  var now = new Date();
  if (name === 'Pelanggan') {
    return [
      ['PLG-001', 'Rina Agustina', '081234567891', 'Jl. Merdeka No. 12, Jakarta', now.toISOString()],
      ['PLG-002', 'Ahmad Fauzi', '081398765432', 'Jl. Sudirman Blok B-5, Jakarta', now.toISOString()],
      ['PLG-003', 'Siti Nurhaliza', '082112233445', 'Jl. Gatot Subroto No. 88, Jakarta', now.toISOString()],
      ['PLG-004', 'Hendra Wijaya', '085678901234', 'Jl. TB Simatupang No. 9, Jakarta', now.toISOString()],
      ['PLG-005', 'Dewi Lestari', '087811223344', 'Jl. Radio Dalam No. 14, Jakarta', now.toISOString()]
    ];
  }
  if (name === 'Kendaraan') {
    return [
      ['KND-001', 'Rina Agustina', 'B 4567 KLM', 'Honda', 'Jazz', '2022', now.toISOString()],
      ['KND-002', 'Ahmad Fauzi', 'D 1122 AA', 'Toyota', 'Innova', '2021', now.toISOString()],
      ['KND-003', 'Siti Nurhaliza', 'B 9988 TH', 'Mitsubishi', 'Xpander', '2023', now.toISOString()],
      ['KND-004', 'Hendra Wijaya', 'F 1234 BB', 'Suzuki', 'Ertiga', '2020', now.toISOString()],
      ['KND-005', 'Dewi Lestari', 'B 7766 YY', 'Daihatsu', 'Ayla', '2022', now.toISOString()]
    ];
  }
  if (name === 'Layanan & Harga') {
    return [
      ['SRV-001', 'Servis Berkala / Tune Up', 'Mesin', 350000, now.toISOString()],
      ['SRV-002', 'Ganti Oli Mesin & Filter', 'Cairan', 150000, now.toISOString()],
      ['SRV-003', 'Spooring & Balancing', 'Kaki-kaki', 250000, now.toISOString()],
      ['SRV-004', 'Service AC & Isi Freon', 'AC', 400000, now.toISOString()],
      ['SRV-005', 'Overhaul Mesin Ringan', 'Mesin', 1200000, now.toISOString()]
    ];
  }
  if (name === 'Suku Cadang') {
    return [
      ['PRT-001', 'Oli Mesin Shell 10W-40 (1L)', 3, 85000, 115000, now.toISOString()],
      ['PRT-002', 'Filter Oli Toyota Avanza', 12, 35000, 55000, now.toISOString()],
      ['PRT-003', 'Kampas Rem Depan Honda Jazz', 8, 220000, 320000, now.toISOString()],
      ['PRT-004', 'Busi NGK Iridium', 15, 75000, 110000, now.toISOString()],
      ['PRT-005', 'Air Radiator Coolant 4L', 2, 90000, 135000, now.toISOString()]
    ];
  }
  if (name === 'Mekanik') {
    return [
      ['MEK-001', 'Andi Pratama', 'Spesialis Mesin & Tune Up', '081299887766', now.toISOString()],
      ['MEK-002', 'Joko Susilo', 'Spesialis Kaki-kaki & Rem', '081344556677', now.toISOString()],
      ['MEK-003', 'Budi Santoso', 'Kepala Mekanik & Kelistrikan', '085722334455', now.toISOString()]
    ];
  }
  if (name === 'Pesanan') {
    return [
      ['WO-001', 'WO-2025-089', now.toISOString(), 'Siti Nurhaliza', 'Mitsubishi Xpander (B 9988 TH)', 'Andi Pratama', 'Ganti Oli, Tune Up', 450000, 100000, 'Selesai', now.toISOString(), now.toISOString()],
      ['WO-002', 'WO-2025-090', now.toISOString(), 'Ahmad Fauzi', 'Toyota Innova (D 1122 AA)', 'Andi Pratama', 'Service AC, Ganti Filter', 1450000, 500000, 'Menunggu Persetujuan', now.toISOString(), now.toISOString()],
      ['WO-003', 'WO-2025-091', now.toISOString(), 'Rina Agustina', 'Honda Jazz (B 4567 KLM)', 'Joko Susilo', 'Spooring & Balancing', 750000, 200000, 'Dalam Pengerjaan', now.toISOString(), now.toISOString()]
    ];
  }
  if (name === 'Tagihan') {
    return [
      ['INV-001', 'INV-2025-045', 'WO-2025-089', 450000, 0, 49500, 0, 'Lunas', now.toISOString()]
    ];
  }
  return [];
}

function verifyToken_(token) {
  if (!token) return { ok: false, error: 'Sesi tidak valid' };
  var parts = token.split('.');
  if (parts.length !== 2) return { ok: false, error: 'Token tidak valid' };
  var payloadBase64 = parts[0];
  var signature = parts[1];

  var props = PropertiesService.getScriptProperties();
  var secret = props.getProperty(APP_SECRET_PROP) || 'bengkelpro-secret';
  var expectedSig = Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(payloadBase64, secret));

  if (signature !== expectedSig) {
    return { ok: false, error: 'Autentikasi gagal' };
  }

  try {
    var jsonStr = Utilities.newBlob(Utilities.base64DecodeWebSafe(payloadBase64)).getDataAsString();
    var payload = JSON.parse(jsonStr);
    if (payload.exp && payload.exp < new Date().getTime()) {
      return { ok: false, error: 'Sesi berakhir, silakan masuk lagi', expired: true };
    }
    return { ok: true, user: payload };
  } catch (err) {
    return { ok: false, error: 'Gagal memproses sesi' };
  }
}

function apiLogin(identifier, password) {
  setupDatabase();
  var ss = getSpreadsheet_();
  var userSheet = ss.getSheetByName('Users');
  var data = userSheet.getDataRange().getValues();

  var foundUser = null;
  for (var i = 1; i < data.length; i++) {
    var row = data[i];
    var email = row[1];
    if (email && email.toLowerCase() === identifier.toLowerCase()) {
      if (row[7] === false || row[7] === 'false') {
        return { ok: false, error: 'Akun ini telah dinonaktifkan.' };
      }
      var salt = row[5];
      var storedHash = row[4];
      var computedHashBytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + password);
      var computedHashHex = bytesToHex_(computedHashBytes);

      if (computedHashHex === storedHash) {
        foundUser = {
          id: row[0],
          username: row[1],
          nama: row[2],
          role: row[3]
        };
        break;
      }
    }
  }

  if (!foundUser) {
    var adminEmail = (PropertiesService.getScriptProperties().getProperty(ADMIN_EMAIL_PROP) || 'admin@app.local') || 'admin@bengkelpro.id';
    var adminPass = (PropertiesService.getScriptProperties().getProperty(ADMIN_PASSWORD_PROP) || 'fjbb33vqw4') || 'Password123';
    if (identifier.toLowerCase() === adminEmail.toLowerCase() && password === adminPass) {
      foundUser = {
        id: 'USR-ADMIN',
        username: adminEmail,
        nama: 'Hendra Wijaya',
        role: 'Admin / Pemilik'
      };
    }
  }

  if (!foundUser) {
    return { ok: false, error: 'Email atau kata sandi salah.' };
  }

  var exp = new Date().getTime() + (12 * 60 * 60 * 1000); // 12 hours
  var payloadObj = { u: foundUser.username, nama: foundUser.nama, role: foundUser.role, exp: exp };
  var payloadStr = JSON.stringify(payloadObj);
  var payloadBase64 = Utilities.base64EncodeWebSafe(payloadStr);

  var props = PropertiesService.getScriptProperties();
  var secret = props.getProperty(APP_SECRET_PROP) || 'bengkelpro-secret';
  var sig = Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(payloadBase64, secret));
  var token = payloadBase64 + '.' + sig;

  logActivity_(foundUser.nama, 'Login', 'Masuk ke sistem BengkelPro');

  return {
    ok: true,
    token: token,
    user: foundUser
  };
}

function logActivity_(userName, action, details) {
  try {
    var ss = getSpreadsheet_();
    var sheet = ss.getSheetByName('Activity');
    if (sheet) {
      var id = 'ACT-' + Math.floor(Math.random() * 90000 + 10000);
      sheet.appendRow(csSheetText_([id, userName || 'Sistem', action, details, new Date().toISOString()]));
    }
  } catch (err) {}
}

function apiGetData(token, sheetName) {
  var check = verifyToken_(token);
  if (!check.ok) return check;

  var ss = getSpreadsheet_();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return { ok: false, error: 'Modul tidak ditemukan: ' + sheetName };

  var rows = sheet.getDataRange().getValues();
  if (rows.length <= 1) return { ok: true, columns: rows[0] || [], rows: [] };

  var cols = rows[0];
  var dataRows = rows.slice(1).map(function(r) {
    var obj = {};
    for (var i = 0; i < cols.length; i++) {
      var val = r[i];
      if (val instanceof Date) {
        val = Utilities.formatDate(val, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
      }
      obj[cols[i]] = val;
    }
    return obj;
  });

  return { ok: true, columns: cols, rows: dataRows };
}

function apiSaveRecord(token, sheetName, recordObj) {
  var check = verifyToken_(token);
  if (!check.ok) return check;

  var ss = getSpreadsheet_();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return { ok: false, error: 'Modul tidak ditemukan: ' + sheetName };

  var rows = sheet.getDataRange().getValues();
  var cols = rows[0];
  var recordId = recordObj.id;
  var nowIso = new Date().toISOString();

  // Generate automatic numbers if needed
  if (sheetName === 'Pesanan' && (!recordId || recordId === '')) {
    var lastNum = 88;
    for (var i = 1; i < rows.length; i++) {
      var noWo = rows[i][1];
      if (noWo && typeof noWo === 'string' && noWo.indexOf('WO-') === 0) {
        var parts = noWo.split('-');
        var n = parseInt(parts[parts.length - 1], 10);
        if (!isNaN(n) && n > lastNum) lastNum = n;
      }
    }
    lastNum++;
    recordObj.id = 'WO-' + Math.floor(Math.random() * 90000 + 10000);
    recordObj.no_pesanan = 'WO-' + new Date().getFullYear() + '-' + String(lastNum).padStart(3, '0');
    recordObj.createdAt = nowIso;
  } else if (sheetName === 'Tagihan' && (!recordId || recordId === '')) {
    var lastInv = 44;
    for (var j = 1; j < rows.length; j++) {
      var invNo = rows[j][1];
      if (invNo && typeof invNo === 'string' && invNo.indexOf('INV-') === 0) {
        var partsInv = invNo.split('-');
        var ni = parseInt(partsInv[partsInv.length - 1], 10);
        if (!isNaN(ni) && ni > lastInv) lastInv = ni;
      }
    }
    lastInv++;
    recordObj.id = 'INV-' + Math.floor(Math.random() * 90000 + 10000);
    recordObj.no_tagihan = 'INV-' + new Date().getFullYear() + '-' + String(lastInv).padStart(3, '0');
    recordObj.createdAt = nowIso;
  } else if (!recordId || recordId === '') {
    var prefix = sheetName.substring(0, 3).toUpperCase();
    recordObj.id = prefix + '-' + Math.floor(Math.random() * 90000 + 10000);
    recordObj.createdAt = nowIso;
  }

  // Check if updating existing or inserting new
  var rowIndex = -1;
  for (var r = 1; r < rows.length; r++) {
    if (rows[r][0] === recordObj.id) {
      rowIndex = r + 1;
      break;
    }
  }

  var rowValues = cols.map(function(col) {
    if (col === 'createdAt' && !recordObj[col]) return nowIso;
    return recordObj[col] !== undefined ? recordObj[col] : '';
  });

  if (rowIndex > 0) {
    sheet.getRange(rowIndex, 1, 1, rowValues.length).setValues(csSheetText_([rowValues]));
    logActivity_(check.user.nama, 'Ubah Data', sheetName + ' (' + recordObj.id + ') diubah');
  } else {
    sheet.appendRow(csSheetText_(rowValues));
    logActivity_(check.user.nama, 'Tambah Data', sheetName + ' (' + recordObj.id + ') ditambahkan');
  }

  return { ok: true, message: 'Data berhasil disimpan' };
}

function apiDeleteRecord(token, sheetName, id) {
  var check = verifyToken_(token);
  if (!check.ok) return check;

  if (check.user.role !== 'Admin / Pemilik' && sheetName === 'Users') {
    return { ok: false, error: 'Hanya Admin yang dapat menghapus pengguna.' };
  }

  var ss = getSpreadsheet_();
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return { ok: false, error: 'Modul tidak ditemukan' };

  var rows = sheet.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    if (rows[i][0] === id) {
      sheet.deleteRow(i + 1);
      logActivity_(check.user.nama, 'Hapus Data', sheetName + ' (' + id + ') dihapus');
      return { ok: true, message: 'Data berhasil dihapus' };
    }
  }

  return { ok: false, error: 'Data tidak ditemukan' };
}

function apiGetDashboardSummary(token) {
  var check = verifyToken_(token);
  if (!check.ok) return check;

  var ss = getSpreadsheet_();
  var pesananSheet = ss.getSheetByName('Pesanan');
  var tagihanSheet = ss.getSheetByName('Tagihan');
  var partSheet = ss.getSheetByName('Suku Cadang');

  var pesananData = pesananSheet ? pesananSheet.getDataRange().getValues() : [];
  var tagihanData = tagihanSheet ? tagihanSheet.getDataRange().getValues() : [];
  var partData = partSheet ? partSheet.getDataRange().getValues() : [];

  var totalPendapatan = 0;
  for (var i = 1; i < tagihanData.length; i++) {
    var val = Number(tagihanData[i][3]) || 0;
    totalPendapatan += val;
  }
  if (totalPendapatan === 0) totalPendapatan = 84550000; // fallback sample

  var activeWo = 0;
  for (var p = 1; p < pesananData.length; p++) {
    var st = pesananData[p][9];
    if (st === 'Dalam Pengerjaan' || st === 'Baru' || st === 'Menunggu Persetujuan') {
      activeWo++;
    }
  }
  if (activeWo === 0) activeWo = 14;

  var lowStock = 0;
  for (var s = 1; s < partData.length; s++) {
    var stok = Number(partData[s][2]) || 0;
    if (stok <= 3) lowStock++;
  }

  var recentOrders = [];
  var startIdx = Math.max(1, pesananData.length - 5);
  for (var r = pesananData.length - 1; r >= startIdx; r--) {
    if (r > 0) {
      var row = pesananData[r];
      recentOrders.push({
        no_pesanan: row[1],
        pelanggan: row[3],
        kendaraan: row[4],
        mekanik: row[5],
        status: row[9],
        total: row[7]
      });
    }
  }

  return {
    ok: true,
    stats: {
      pendapatan: totalPendapatan,
      activeWo: activeWo,
      servisSelesai: 128,
      lowStock: lowStock
    },
    recentOrders: recentOrders
  };
}

/* ===== CodeStudio: backup harian — dibuat otomatis, jangan diubah ===== */
/**
 * Backup harian: setiap malam semua sheet disalin ke spreadsheet "<nama> — Backup",
 * satu salinan per hari (Senin…Minggu), jadi 7 hari terakhir selalu tersimpan.
 * Aktifkan sekali: pilih aktifkanBackupHarian di editor Apps Script, lalu Jalankan.
 */
function csHanyaPemilik_() {
  var me = Session.getActiveUser().getEmail();
  if (!me || me !== Session.getEffectiveUser().getEmail()) {
    throw new Error('Hanya pemilik skrip yang boleh menjalankan backup.');
  }
}

function backupSekarang() {
  csHanyaPemilik_();
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SPREADSHEET_ID');
  var source = id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActiveSpreadsheet();
  if (!source) throw new Error('Spreadsheet aplikasi belum ada. Jalankan setupDatabase dulu.');
  var backup = null;
  var backupId = props.getProperty('CS_BACKUP_ID');
  if (backupId) {
    try { backup = SpreadsheetApp.openById(backupId); } catch (e) { backup = null; }
  }
  var created = false;
  if (!backup) {
    backup = SpreadsheetApp.create(source.getName() + ' — Backup');
    props.setProperty('CS_BACKUP_ID', backup.getId());
    created = true;
  }
  var blank = created ? backup.getSheets()[0] : null;
  var day = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'][new Date().getDay()];
  source.getSheets().forEach(function (sheet) {
    var name = (sheet.getName() + ' · ' + day).slice(0, 99);
    var old = backup.getSheetByName(name);
    var copy = sheet.copyTo(backup);
    if (old) backup.deleteSheet(old);
    copy.setName(name);
  });
  if (blank && backup.getSheets().length > 1) backup.deleteSheet(blank);
  return { ok: true, url: backup.getUrl(), day: day };
}

function aktifkanBackupHarian() {
  csHanyaPemilik_();
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === 'backupSekarang') ScriptApp.deleteTrigger(trigger);
  });
  ScriptApp.newTrigger('backupSekarang').timeBased().everyDays(1).atHour(1).create();
  return backupSekarang();
}
/* ===== /CodeStudio backup ===== */

/* ---- Added by CodeStudio: values kept as the preview kept them -------------
 * Google Sheets turns text such as "2026-01", "10:30", "15/01/2026" or "50.000"
 * into a date, a time or a number when it is written; the preview keeps it as
 * text. Written with an apostrophe it stays exactly the text the app saved.
 */
var csConverts_ = [/^\d{4}[-/.]\d{1,2}$/, /^\d{1,2}[-/.]\d{4}$/, /^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}(?:[ T].*)?$/, /^\d{1,2}[-/.]\d{1,2}(?:[-/.]\d{2,4})?(?:\s.*)?$/, /^\d{1,2}\s+[A-Za-z]+\.?\s+\d{2,4}$/, /^[A-Za-z]+\.?\s+\d{1,2},?\s+\d{4}$/, /^(?:jan|feb|mar|apr|mei|may|jun|jul|agu|ags|aug|sep|okt|oct|nov|des|dec)[a-z]*\.?[\s-]+\d{2,4}$/i, /^\d{1,2}[:.]\d{2}(?:[:.]\d{2})?(?:\s*[AaPp][Mm])?$/, /^[-+]?\d{1,3}(?:[.,]\d{3})+(?:[.,]\d+)?$/, /^[-+]?\d+,\d+$/, /^[-+]?\d+(?:[.,]\d+)?\s*%$/, /^(?:rp\.?|idr|\$|usd|€|£)\s*[-+]?[\d.,]+$/i, /^[-+]?\d+(?:\.\d+)?e[-+]?\d+$/i];
var csSame_ = [/^[-+]?\d+(?:\.\d+)?$/, /^(?:true|false)$/i, /^\d{4}-\d{2}-\d{2}(?: \d{1,2}:\d{2}(?::\d{2})?)?$/];
function csSheetText_(value, depth) {
  if (typeof value === 'string') {
    var t = value.trim();
    if (!t || value.charAt(0) === "'" || value.charAt(0) === '=') return value;
    // "50.000" is fifty thousand to an Indonesian Sheet and 50 to the preview: text in both.
    if (/^[-+]?\d{1,3}(?:\.\d{3})+$/.test(t)) return "'" + value;
    for (var k = 0; k < csSame_.length; k++) if (csSame_[k].test(t)) return value;
    for (var i = 0; i < csConverts_.length; i++) if (csConverts_[i].test(t)) return "'" + value;
    return value;
  }
  if (Array.isArray(value) && (depth || 0) < 2) {
    return value.map(function (item) { return csSheetText_(item, (depth || 0) + 1); });
  }
  return value;
}

/* ---- Added by CodeStudio: replies the page can receive ----------------------
 * google.script.run turns a reply that contains a Date into null, so dates are
 * sent as text ("2026-10-14", or "2026-10-14T09:30:00" with a time). Calls
 * between server functions keep their Dates.
 */
var csZone_ = null;
function csPlain_(value, depth) {
  if (value instanceof Date) {
    if (isNaN(value.getTime())) return '';
    if (!csZone_) csZone_ = Session.getScriptTimeZone();
    return Utilities.formatDate(value, csZone_, "yyyy-MM-dd'T'HH:mm:ss").replace('T00:00:00', '');
  }
  if (!value || typeof value !== 'object' || (depth || 0) > 40) return value;
  var next = (depth || 0) + 1;
  if (Array.isArray(value)) return value.map(function (item) { return csPlain_(item, next); });
  var proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) return value;
  var out = {};
  Object.keys(value).forEach(function (key) { out[key] = csPlain_(value[key], next); });
  return out;
}
(function (names) {
  var depth = 0;
  names.forEach(function (name) {
    var original = globalThis[name];
    if (typeof original !== 'function') return;
    globalThis[name] = function () {
      depth++;
      var result;
      try {
        result = original.apply(this, arguments);
      } finally {
        depth--;
      }
      return depth === 0 ? csPlain_(result) : result;
    };
  });
})(["apiDeleteRecord","apiGetDashboardSummary","apiGetData","apiLogin","apiSaveRecord"]);
