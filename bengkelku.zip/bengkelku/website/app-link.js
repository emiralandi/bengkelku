// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://bengkelpro-bmwqc3.zedeai2026.workers.dev";
